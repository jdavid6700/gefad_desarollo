<?php
/*--------------------------------------------------------------------------------------------------------------------------
  @ Derechos de Autor: Vea el archivo LICENCIA.txt que viene con la distribucion
---------------------------------------------------------------------------------------------------------------------------*/

if(!isset($GLOBALS["autorizado"]))
{
	include("../index.php");
	exit;		
}
require_once("clase/config.class.php");
	setlocale(LC_MONETARY, 'en_US');
	$esta_configuracion=new config();
	$configuracion=$esta_configuracion->variable();
	 
include_once($configuracion["raiz_documento"].$configuracion["clases"]."/sql.class.php");

class sql_xajax extends sql
{	//@ Método que crea las sentencias sql para el modulo admin_noticias
	function cadena_sql($configuracion,$tipo,$variable)
		{
		    switch($tipo)
			{
					
			case "buscar_unidad":

                                $this->cadena_sql="SELECT DISTINCT ";
                                $this->cadena_sql.="RUB_INTERNO,";
                                $this->cadena_sql.="SUBSTR( `RUB_DESCRIP`, 1, 60 ) ";
                                $this->cadena_sql.=" FROM ";
                                $this->cadena_sql.="DMD_FIN_RUBRO ";
                                $this->cadena_sql.="INNER JOIN DMH_FIN_APROPIACION ";
                                $this->cadena_sql.="ON APROP_RUB_INTERNO=RUB_INTERNO ";
                                $this->cadena_sql.=" WHERE ";
                                $this->cadena_sql.="APROP_COD_UNI=";
                                $this->cadena_sql.="'".$variable."' ";
                                $this->cadena_sql.="GROUP BY APROP_RUB_INTERNO ";
                                $this->cadena_sql.="ORDER BY RUB_DESCRIP ASC";
                           break;
								
			}
		return $this->cadena_sql;
		
		}
}
?>
